public class Principal {
    public static void main(String[] args){
    Sig sig = new Sig();
        sig.executar();
    }
}