public class PaoFrances extends Sanduiches{
    
    public PaoFrances(String nome){
        setNome(nome);
    }

    @Override
    public double getPreco(){
        return 1.5;
    }

}
