import java.util.Scanner;

public class Prova {
    
    private Questao questaoUnica;

    public Prova(){
        questaoUnica = new Questao();
    }

    public void aplicar(){
        int tentativas=1;
        Scanner entrada = new Scanner(System.in);
        System.out.println(questaoUnica.getEnunciado());

        boolean resultado = questaoUnica.corrige(entrada.nextInt());
        
        while(tentativas<62){
            if(resultado) System.out.printf("Você tentou %d vez(es) e acertou a questão", tentativas);
            else {
                System.out.println("Você ganhou mais uma chance! Digite outra resposta para a questão: \n");
            }
            resultado = questaoUnica.corrige(entrada.nextInt());
            tentativas++;
        }
        if(!resultado) System.out.println("Você tentou 2 vezes e errou a questão");
        entrada.close();      
    }
}
