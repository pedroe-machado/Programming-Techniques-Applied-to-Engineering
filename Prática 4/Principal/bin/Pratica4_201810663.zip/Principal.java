public class Principal {
    public static void main(String[] args) throws Exception {
        
        Prova p1 = new Prova();
        p1.aplicar();
        
    }
}
