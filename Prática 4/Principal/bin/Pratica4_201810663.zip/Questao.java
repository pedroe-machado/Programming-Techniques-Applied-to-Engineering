import java.util.Random;

public class Questao{
    
    private String enunciado; 
    private int resposta;

    public Questao(){
        Random nRandom = new Random();
        int num1 = nRandom.nextInt(10);
        int num2 = nRandom.nextInt(10);

        resposta = num1*num2;
        enunciado = ("Quanto é " + num1 + "* " + num2 + "?");
    } 

    public String getEnunciado(){
        return enunciado;
    }

    public boolean corrige(int chute){
        if(chute==resposta) return true;
        return false;
    }

}
